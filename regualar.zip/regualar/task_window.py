import tkinter as tk
import objects_management as om


class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master

        # Set up the canvas
        window_width = 1400
        window_height = 750
        self.canvas = tk.Canvas(self.master, width=window_width, height=window_height, bg="#ECFFDC")
        self.canvas.pack()

        # Bind mouse events to the canvas
        self.canvas.bind("<ButtonPress-1>", self.mouse_left_button_press)

        # Initialize object manager and generate objects
        object_num = 22  # Total number of objects
        object_radius = 20  # Radius of each object
        self.object_manage = om.ObjectManager(
            self.canvas, window_width, window_height, object_num, object_radius
        )
        self.object_manage.generate_random_targets()

    def mouse_left_button_press(self, event):
        x = event.x
        y = event.y
        selected_object_index = self.object_manage.get_object_index_at_position(x, y)
        if selected_object_index == -1:
            return  # No object selected

        # Change the object's color to yellow to indicate selection
        self.object_manage.select_object(selected_object_index)


if __name__ == '__main__':
    master = tk.Tk()
    master.title("Normal cursor application")
    master.resizable(height=True, width=True)
    app = Application(master=master)
    app.mainloop()  # Run the Tkinter event loop
