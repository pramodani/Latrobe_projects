import math
import random

# Initialize objects
class Circle:
    def __init__(self, x, y, radius, circle_type='distractor'):
        self.x = x
        self.y = y
        self.radius = radius
        self.type = circle_type
        self.selected = False  # Indicates whether the object has been selected


# Initialize the ObjectManager.
class ObjectManager:
    def __init__(self, canvas, window_width, window_height, object_num, object_radius):
        self.canvas = canvas
        self.window_width = window_width
        self.window_height = window_height
        self.object_num = object_num  # Total number of objects
        self.object_radius = object_radius
        self.objects = []  # Store all Circle objects
        self.object_tag_in_canvas = []  # Store the canvas tags of the objects

    # Generate the start button, target, and distractors and place them on screen
    def generate_random_targets(self):
        # Position start button left bottom corner
        start_button = Circle(
            x=self.object_radius,  # Positioned at the left corner
            y=self.window_height - self.object_radius,  # Positioned at the bottom corner
            radius=self.object_radius,
            circle_type='start'
        )
        self.objects.append(start_button)

        # Create target with random position
        target = Circle(
            x=random.randint(self.object_radius, self.window_width - self.object_radius),
            y=random.randint(self.object_radius, self.window_height - self.object_radius),
            radius=self.object_radius,
            circle_type='target'
        )
        self.objects.append(target)

        # Create distractors
        distractor_count = self.object_num - 2  # Exclude start and target
        i = 0
        while i < distractor_count:
            new_object = Circle(
                x=random.randint(self.object_radius, self.window_width - self.object_radius),
                y=random.randint(self.object_radius, self.window_height - self.object_radius),
                radius=self.object_radius,
                circle_type='distractor'
            )
            overlap = False
            # Check for overlap with existing objects
            for existing_object in self.objects:
                if self.check_two_targets_overlap(new_object, existing_object):
                    overlap = True
                    break

            if not overlap:
                self.objects.append(new_object)
                i += 1

        self.paint_objects()

    # place object on canvas
    def paint_objects(self):
        for obj in self.objects:
            if obj.type == 'start':
                fill_color = 'blue'
            elif obj.type == 'target':
                fill_color = 'red'
            else:
                fill_color = 'green'

            tag = self.canvas.create_oval(
                obj.x - obj.radius, obj.y - obj.radius,
                obj.x + obj.radius, obj.y + obj.radius,
                fill=fill_color, outline="", width=0
            )
            self.object_tag_in_canvas.append(tag)

    # check if circles overlap
    def check_two_targets_overlap(self, t1, t2):
        distance = math.hypot(t1.x - t2.x, t1.y - t2.y)
        return distance < (t1.radius + t2.radius)

    # Get the index of the object at the given position , x,y coordinates
    def get_object_index_at_position(self, x, y):
        for index, obj in enumerate(self.objects):
            distance = math.hypot(obj.x - x, obj.y - y)
            if distance <= obj.radius:
                return index
        return -1

    # Select the object at the given index, changing its color to yellow.
    def select_object(self, object_index):
        if object_index >= 0:
            obj = self.objects[object_index]
            object_tag = self.object_tag_in_canvas[object_index]
            if not obj.selected:
                # Change the object's color to yellow
                self.canvas.itemconfig(object_tag, fill="yellow")
                obj.selected = True  # Mark the object as selected
