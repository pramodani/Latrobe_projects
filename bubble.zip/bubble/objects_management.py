import math
import random


# To initialize a Circle object and attributes
class Circle:
    def __init__(self, x, y, radius, circle_type='distractor'):
        self.x = x
        self.y = y
        self.radius = radius
        self.type = circle_type 


class ObjectManager:
    def __init__(self, canvas, window_width, window_height, object_num, object_radius):
        self.canvas = canvas
        self.window_width = window_width
        self.window_height = window_height
        self.object_num = object_num  # Total number of objects
        self.object_radius = object_radius
        self.objects = []  # Store all Circle objects
        self.object_tag_in_canvas = []  # Store the canvas tags of the objects
        self.last_selected_object_index = -1  # Index of the last selected object

    # updating object color based on cursor movement
    # if moved closers object turns yellow
    def update_object(self, object_index):
        if object_index >= 0:
            object_tag = self.object_tag_in_canvas[object_index]
            if self.last_selected_object_index != object_index:
                # Reset the appearance of the last selected object
                if self.last_selected_object_index >= 0:
                    last_obj = self.objects[self.last_selected_object_index]
                    last_obj_tag = self.object_tag_in_canvas[self.last_selected_object_index]
                    self.reset_object_appearance(last_obj, last_obj_tag)

                self.canvas.itemconfig(object_tag, fill="yellow", outline="gray", width=5)
                self.last_selected_object_index = object_index
        else:
            # No object is selected; reset the last selected object's appearance
            if self.last_selected_object_index >= 0:
                last_obj = self.objects[self.last_selected_object_index]
                last_obj_tag = self.object_tag_in_canvas[self.last_selected_object_index]
                self.reset_object_appearance(last_obj, last_obj_tag)
                self.last_selected_object_index = -1

    def reset_object_appearance(self, obj, obj_tag):
        if obj.type == 'start':
            self.canvas.itemconfig(obj_tag, fill="blue", outline="", width=0)
        elif obj.type == 'target':
            self.canvas.itemconfig(obj_tag, fill="red", outline="", width=0)
        elif obj.type == 'distractor':
            self.canvas.itemconfig(obj_tag, fill="green", outline="", width=0)

    # place object on canvas
    def paint_objects(self):
        for obj in self.objects:
            if obj.type == 'start':
                fill_color = 'blue'
            elif obj.type == 'target':
                fill_color = 'red'
            else:
                fill_color = 'green'

            tag = self.canvas.create_oval(
                obj.x - obj.radius, obj.y - obj.radius,
                obj.x + obj.radius, obj.y + obj.radius,
                fill=fill_color, outline=fill_color, width=0
            )
            self.object_tag_in_canvas.append(tag)

    # generate all objects, start, target and distractors
    def generate_random_targets(self):
        # Position the start button in bottom left corner
        start_button = Circle(
            x=self.object_radius,  # Positioned at the left corner
            y=self.window_height - self.object_radius,  # Positioned at the bottom
            radius=self.object_radius,
            circle_type='start'
        )
        self.objects.append(start_button)

        # Create target with random position
        target = Circle(
            x=random.randint(self.object_radius, self.window_width - self.object_radius),
            y=random.randint(self.object_radius, self.window_height - self.object_radius),
            radius=self.object_radius,
            circle_type='target'
        )
        self.objects.append(target)

        # Create distractors
        distractor_count = self.object_num - 2  # Exclude start and target
        i = 0
        while i < distractor_count:
            new_object = Circle(
                x=random.randint(self.object_radius, self.window_width - self.object_radius),
                y=random.randint(self.object_radius, self.window_height - self.object_radius),
                radius=self.object_radius,
                circle_type='distractor'
            )
            overlap = False
            # Check for overlap with existing objects
            for existing_object in self.objects:
                if self.check_two_targets_overlap(new_object, existing_object):
                    overlap = True
                    break

            if not overlap:
                self.objects.append(new_object)
                i += 1

        self.paint_objects()
        return self.objects

    # checking if two object are overlapping each other
    def check_two_targets_overlap(self, t1, t2):
        if math.hypot(t1.x - t2.x, t1.y - t2.y) > (t1.radius + t2.radius):
            return False
        else:
            return True
