import math


class BubbleCursor:
    def __init__(self, canvas, objects, x=0, y=0):
        self.x = x
        self.y = y
        self.radius = 30  # Initial radius of the cursor
        self.canvas = canvas
        self.objects = objects  # list of objects that the cursor can interact with.
        self.cursor_size = 7  # Size of the crosshair lines

        # Create the bubble cursor appearance
        self.cursor_tag_circle = self.canvas.create_oval(
            x - self.radius, y - self.radius, x + self.radius, y + self.radius,
            fill="grey", outline="grey", width=0
        )
        self.canvas.tag_lower(self.cursor_tag_circle)  # Move the cursor's circle to the bottom level
        # Create horizontal and vertical crosshair lines
        self.cursor_tag_horizontal = self.canvas.create_line(
            x - self.cursor_size, y, x + self.cursor_size, y,
            fill='black', width=2
        )
        self.cursor_tag_vertical = self.canvas.create_line(
            x, y - self.cursor_size, x, y + self.cursor_size,
            fill='black', width=2
        )
        self.selected_object = -1  # Index of the currently selected object (-1 means none)

    # update cursor based on new coordinated
    def update_cursor(self, x, y):
        self.x = x
        self.y = y
        self._determine_selected_object()  # Determine which object is currently selected
        # Update the cursor's circle position
        self.canvas.coords(
            self.cursor_tag_circle,
            x - self.radius, y - self.radius, x + self.radius, y + self.radius
        )
        # Update the horizontal crosshair position
        self.canvas.coords(
            self.cursor_tag_horizontal,
            x - self.cursor_size, y, x + self.cursor_size, y
        )
        # Update the vertical crosshair position
        self.canvas.coords(
            self.cursor_tag_vertical,
            x, y - self.cursor_size, x, y + self.cursor_size
        )

    # return index of the selected object, or -1 if no object is selected.
    def get_selected_object(self):
        return self.selected_object

    # Determine which object is closest to the cursor and update the cursor
    def _determine_selected_object(self):
        min_distance = float('inf')
        closest_object_index = -1

        # Find the closest object to the cursor
        for i, obj in enumerate(self.objects):
            # Calculate distance from cursor center to object border
            distance = math.hypot(obj.x - self.x, obj.y - self.y) - obj.radius
            if distance < min_distance:
                min_distance = distance
                closest_object_index = i

        self.selected_object = closest_object_index

        if closest_object_index != -1:
            # Adjust the radius to reach the edge of the closest object
            self.radius = min_distance + self.objects[closest_object_index].radius
            # Ensure the radius is at least as large as the cursor size
            self.radius = max(self.radius, self.cursor_size)
        else:
            # Default radius when no object is nearby
            self.radius = self.cursor_size

    def update_cursor_appearance(self):
        self.canvas.itemconfig(
            self.cursor_tag_circle, outline="grey", width=2
        )
