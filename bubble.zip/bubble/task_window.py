import tkinter as tk
import bubble_cursor
import objects_management as om


class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)  
        self.master = master  # Update the master object after tk.Frame() makes necessary changes to it

        # Set up the canvas
        window_width = 1400
        window_height = 780
        self.canvas = tk.Canvas(self.master, width=window_width, height=window_height, bg="#ECFFDC")
        self.canvas.pack()

        # Bind mouse events to the canvas
        self.canvas.bind("<Motion>", self.mouse_move)

        # Initialize object manager from object_management file and generate objects
        object_num = 22  # Total number of objects
        object_radius = 20  # Radius of each object
        self.object_manage = om.ObjectManager(
            self.canvas, window_width, window_height, object_num, object_radius
        )
        objects = self.object_manage.generate_random_targets()

        # Initialize the bubble cursor from bubble_cursor file
        self.cursor = bubble_cursor.BubbleCursor(self.canvas, objects)
        self.object_index = 0  # Index of the currently selected object set to zero

    def mouse_move(self, event):
        # Update the cursor position
        self.cursor.update_cursor(event.x, event.y)

        # Get the index of the object currently under the cursor
        self.object_index = self.cursor.get_selected_object()

        # Update the appearance of objects based on cursor movement
        self.object_manage.update_object(self.object_index)


if __name__ == '__main__':
    master = tk.Tk()
    master.title("Bubble cursor application")
    master.config(cursor="none")  # Hide the default cursor in the canvas
    master.resizable(height=True, width=True)
    app = Application(master=master)
    app.mainloop()  # Run the Tkinter event loop
