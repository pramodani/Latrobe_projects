<?php
// Do NOT put anything before this PHP tag

// This PHP file will have no HTML


include('Functions.php');
date_default_timezone_set("Australia/Melbourne");
$cookieUser = getCookieUser();

if (isset($_POST["Topic"])) {

	$dbh = connectToDatabase();

	$Topic = trim($_POST["Topic"]);

	if (empty($Topic)) {
		setCookieMessage("Topic needs to be provided");
		redirect("Topics.php");

	}else{
		$statement = $dbh->prepare("SELECT * FROM Topic WHERE Topic = ? COLLATE NOCASE;");
		$statement->bindValue(1, $Topic);
		$statement->execute();

		if ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
			setCookieMessage("The Topic " . $Topic . " is already taken. Please try again with another topic.");
			redirect("Topics.php");
		} else {
			$statement2 = $dbh->prepare("SELECT UserID FROM User WHERE UserName = ?;");
			$statement2->bindValue(1, $cookieUser);
			$statement2->execute();
			$row = $statement2->fetch(PDO::FETCH_ASSOC);
			$userid = $row['UserID'];
			
			$statement3 = $dbh->prepare("INSERT INTO Topic (UserID,DateTime,Topic)VALUES(?,?,?);");
			$statement3->bindValue(1, $userid);
			$statement3->bindValue(2, date("Y-m-d H:i:s"));
			$statement3->bindValue(3, $Topic);

			$statement3->execute();

			redirect("Topics.php");

		}
	}

}

?>






