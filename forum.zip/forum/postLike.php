<?php // <--- do NOT put anything before this PHP tag
// this php file will have no HTML

include('Functions.php');

$cookieUser = getCookieUser();
$thisTopic = $_GET['Topic'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$postId = $_POST['postId'];

	if (!empty($postId)) {
		$dbh = connectToDatabase();

		$statement = $dbh->prepare("UPDATE Post SET Likes = Likes + 1 WHERE PostID = ?");
		$statement->bindValue(1, $postId);
		$statement->execute();
		redirect("Forum.php?Topic=$thisTopic");
	} 

}


?>