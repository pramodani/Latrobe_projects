<?php // <--- do NOT put anything before this PHP tag
session_start();

include('Functions.php');
$cookieMessage = getCookieMessage();
$cookieUser = getCookieUser();
?>


<!DOCTYPE html>
<html>
<head>
	<title>  </title>
	<link rel="stylesheet" type="text/css" href="styles.css"> 
</head>
<body>
	<div class="container">

		<!--Header -->
		<div class="row", id="header">
			<h2>CSE4IFU - SignUp</h2>
		</div>

		<!-- Navigation bar -->
		<div class="row", id="nav">  
			<div class="link-container">
				<ul class="nav-list">
					<li><a href="Homepage.php">Home</a></li>
					<li><a href="Topics.php">Topics</a></li>
					<?php  if ($cookieUser == ""): ?>
						<li><a href="SignUp.php">Sign Up</a></li>
						<li><a href="SignIn.php">Sign In</a></li>
					<?php  else: ?>
						<li><a href="HomePage.php">Sign Out</a></li>
					<?php  endif; ?>
				</ul>
			</div>
			<?php  if ($cookieUser != ""):?>
				<div class="name-container">
					<p> <?php echo $cookieUser; ?> </p>
				</div>
			<?php  endif; ?>
		</div>

		<!-- Content -->
		<div class="row", id="content">
			<div class="signinform-container">

				<?php  if ($cookieMessage != ""): ?>
					<p><?php echo $cookieMessage; ?></p>
				<?php  endif; ?>

				<div class="signin-form">
					<form action="AddUser.php" method="POST" novalidate>
						<div>
							<label for="username">Username</label>
							<input type="text" id="username" name="UserName" required><br>
							<label for="firstname">First name</label>
							<input type="text" id="firstname" name="FirstName" required><br>
							<label for="Surname">Surname</label>
							<input type="text" id="surname" name="SurName" required><br>
							<label for="shorttag">Short tag</label>
							<input type="text" id="shorttag" name="Tag" required><br>
						</div>
						<div> 
							<button class="submitbtn" type="submit">Submit</button>
						</div>

					</form>
				</div>
			</div>
		</div>


		<div class="row", id="footer">
			<div> 
				<h3 class="footer-text"> Pramodani Kanchanamala Jayakodi Jayakodi Mudiyanselage - 21978017 - CSE4IFU-2023, Sem 1</h3>
			</div>
		</div>
	</div>
</body>
</html>