<?php
// Do NOT put anything before this PHP tag

// This PHP file will have no HTML


include('Functions.php');
?>

<?php

if (isset($_POST["UserName"]) && isset($_POST["FirstName"]) && isset($_POST["SurName"]) && isset($_POST["Tag"])) {

	$dbh = connectToDatabase();

	$UserName = trim($_POST["UserName"]);
	$FirstName = trim($_POST["FirstName"]);
	$SurName = trim($_POST["SurName"]);
	$Tag = trim($_POST["Tag"]);


	if (empty($UserName)) {
		setCookieMessage("Username not provided.");
		redirect("SignUp.php");

	} elseif (empty($FirstName)) {
		setCookieMessage("First Name not provided.");
		redirect("SignUp.php");

	} elseif (empty($SurName)) {
		setCookieMessage("Surname not provided.");
		redirect("SignUp.php");

	} elseif (empty($Tag)) {
		setCookieMessage("Tag not provided.");
		redirect("SignUp.php");

	}else{
		$statement = $dbh->prepare("SELECT * FROM User WHERE UserName = ? COLLATE NOCASE;");
		$statement->bindValue(1, $UserName);
		$statement->execute();

		if ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
			setCookieMessage("The username " . $UserName . " is already taken. Please sign up again using the form below.");
			redirect("SignUp.php");
		} else {
			$statement2 = $dbh->prepare('INSERT INTO User (UserName,FirstName,SurName,Tag)VALUES(?,?,?,?);');

			$statement2->bindValue(1, $UserName);
			$statement2->bindValue(2, $FirstName);
			$statement2->bindValue(3, $SurName);
			$statement2->bindValue(4, $Tag);

			$statement2->execute();

			setCookieMessage("The user ". $UserName. " has been added. Please sign in to start posting !");
			redirect("Homepage.php");
		}
	}

}
?>

