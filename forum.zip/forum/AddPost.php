<?php // <--- do NOT put anything before this PHP tag

// this php file will have no HTML

include('Functions.php');
$cookieUser = getCookieUser();

$dbh = connectToDatabase();

$Post = trim($_POST['Post']);
$thisTopic = trim($_GET['Topic']);

if (empty($Post)) {
	setCookieMessage("Post needs to be provided");
	redirect("Forum.php");

}else{
	$statement = $dbh->prepare("SELECT * FROM Topic WHERE Topic = ? COLLATE NOCASE;");
	$statement->bindValue(1, $thisTopic);
	$statement->execute();
	$row = $statement->fetch(PDO::FETCH_ASSOC);
	$topicid = $row['TopicID'];

	$statement2 = $dbh->prepare("SELECT UserID FROM User WHERE UserName = ?;");
	$statement2->bindValue(1, $cookieUser);
	$statement2->execute();
	$row = $statement2->fetch(PDO::FETCH_ASSOC);
	$userid = $row['UserID'];

	$statement3 = $dbh->prepare('INSERT INTO Post (UserID, Post, DateTime, TopicID) VALUES (?, ?, ?, ?);');
	date_default_timezone_set("Australia/Melbourne");

	$statement3->bindValue(1, $userid);
	$statement3->bindValue(2, $Post);
	$statement3->bindValue(3, date("Y/m/d H:i:s"));
	$statement3->bindValue(4, $topicid);

	$statement3->execute();
	redirect("Forum.php?Topic=$thisTopic");
}
?>