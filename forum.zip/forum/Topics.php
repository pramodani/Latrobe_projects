<?php // <--- do NOT put anything before this PHP tag
include('Functions.php');
$cookieMessage = getCookieMessage();
$cookieUser = getCookieUser();

$dbh = connectToDatabase();

$statement = $dbh->prepare("SELECT COUNT (TopicID) FROM Topic; ");
$statement->execute();
$topicCount = $statement ->fetchColumn();

$statement2 = $dbh->prepare("SELECT * FROM Topic INNER JOIN User ON Topic.UserID=User.UserID ORDER BY Topic.TopicID desc; ");
$statement2->execute();


?>
<!DOCTYPE html>
<html>
<head>
	<title>  </title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	
</head>
<body>
	<div class="container">
		<!--Header -->
		<div class="row", id="header">
			<h2>CSE4IFU - TOPICS</h2>
		</div>
		<!-- Navigation bar -->
		<div class="row", id="nav">  
			<div class="link-container">
				<ul class="nav-list">
					<li><a href="Homepage.php">Home</a></li>
					<li><a href="Topics.php">Topics</a></li>
					<?php  if ($cookieUser == ""): ?>
						<li><a href="SignUp.php">Sign Up</a></li>
						<li><a href="SignIn.php">Sign In</a></li>
					<?php  else: ?>
						<li><a href="LogOutUser.php">Sign Out</a></li>
					<?php  endif; ?>
				</ul>
			</div>
			<?php  if ($cookieUser != ""):?>
				<div class="name-container">
					<p> <?php echo $cookieUser; ?> </p>
				</div>
			<?php  endif; ?>
		</div>

		<!-- Content -->
		<div class="row", id="content">
			<div class="topictitle"><h3>Have a look at our Topics</h3></div>
			<div class="table">
				<table>
					<tr>
						<th>Created by User</th>
						<th class="tdname">Topic name</th>
						<th>Date created</th>
					</tr>

					 <?php 

					while ($row = $statement2->fetch(PDO::FETCH_ASSOC)) 
					{
						$UserName = $row['UserName'];
						$DateTime = $row['DateTime'];
						$Topic = $row['Topic'];
						echo "<tr>";
						echo "<td> $UserName </td>";
						echo "<td> <a href =\"Forum.php?Topic=$Topic\">$Topic</a> </td>";
						echo "<td> $DateTime </td>";
						echo "</tr>";
					}	
					?> 

				</table>
				
				<div class="newtopicform-container">
					<div class="newtopic-form">
						<h3 id="topich3">Create new Topic</h3><br>
						<?php if ($cookieUser == ""): ?>
							<p>You must be logged in to create a topic.</p>
						<?php else: ?>
							<form action="AddTopic.php" method="POST" novalidate>
								<?php  if ($cookieMessage != ""): ?>
									<p><?php echo $cookieMessage; ?></p>
								<?php  endif; ?>
								<div>
									<label for="topic">Topic</label>
									<input type="text" id="topic" name="Topic" required><br>
								</div>
								<div> 
									<button class="submitbtn-topic" type="submit">Submit</button>
								</div> 

							</form>
						<?php endif;?>
					</div>

				</div>


			</div>
		</div>
		<!-- Footer -->
		<div class="row", id="footer">
			<div> 
				<h3 class="footer-text"> Pramodani Kanchanamala Jayakodi Jayakodi Mudiyanselage - 21978017 - CSE4IFU-2023, Sem 1</h3>
			</div>	
		</div>
	</body>
	</html>
