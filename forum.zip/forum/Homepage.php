<?php // <--- do NOT put anything before this PHP tag
include('Functions.php');
$cookieMessage = getCookieMessage();
$cookieUser = getCookieUser();
?>
<!DOCTYPE html>
<html>
<head>
	<title>  </title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	
</head>
<body>
	<div class="container">
		<!--Header -->
		<div class="row", id="header">
			<h2>CSE4IFU - HOME</h2>
		</div>
		<!-- Navigation bar -->
		<div class="row", id="nav">  
			<div class="link-container">
				<ul class="nav-list">
					<li><a href="Homepage.php">Home</a></li>
					<li><a href="Topics.php">Topics</a></li>
					<?php  if ($cookieUser == ""): ?>
						<li><a href="SignUp.php">Sign Up</a></li>
						<li><a href="SignIn.php">Sign In</a></li>
					<?php  else: ?>
						<li><a href="LogOutUser.php">Sign Out</a></li>
					<?php  endif; ?>
				</ul>
			</div>
			<?php  if ($cookieUser != ""):?>
				<div class="name-container">
					<p> <?php echo $cookieUser; ?> </p>
				</div>
			<?php  endif; ?>
		</div>
		<!-- Container -->
		<div class="row", id="content">
			<?php if (!empty($cookieMessage)) { ?>
				<div class="alert"><?php echo $cookieMessage; ?></div>
				<?php } ?><br>
				<div class="homecontent-container">
					<div class="welcome-message">
						<p>Welcome to our vibrant community forum!</p><br>
						<p>Whether you're here to seek advice, share your knowledge, or engage in discussions peers, you've come to the right place.
							Feel free to explore the various categories, start new threads, and join ongoing conversations.
							Our community is here to support and inspire you on your journey.
							Remember to adhere to our community guidelines and show respect to your fellow members.
						Let's create an inclusive and enriching environment together!</p>
					</div>
						<img src="./images/homepageImage.jpg" alt="homepageImage" class="image1">
				</div>				
			</div>
			<!-- Footer -->
			<div class="row", id="footer">
				<div> 
					<h3 class="footer-text"> Pramodani Kanchanamala Jayakodi Jayakodi Mudiyanselage - 21978017 - CSE4IFU-2023, Sem 1</h3>
				</div>	
			</div>

		</div>
	</body>
	</html>