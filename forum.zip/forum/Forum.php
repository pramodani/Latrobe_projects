<?php // <--- do NOT put anything before this PHP tag

include('Functions.php');
$cookieMessage = getCookieMessage();
$cookieUser = getCookieUser();


if (isset($_GET['Topic']))
	$thisTopic = $_GET['Topic'];
else
	redirect("Topics.php");

$dbh = connectToDatabase();


$statement = $dbh->prepare("SELECT * FROM Topic WHERE topic = ?");
$statement->bindValue(1, $thisTopic);
$statement->execute();
$row = $statement->fetch(PDO::FETCH_ASSOC);
$topicID = $row['TopicID'];

$statement2 = $dbh->prepare("SELECT COUNT(Post.PostID) FROM Post WHERE Post.TopicID = ?");
$statement2->bindValue(1, $topicID);
$statement2->execute();
$count = $statement2->fetchColumn();

$statement3 = $dbh->prepare("SELECT * FROM Post INNER JOIN User ON User.UserID = Post.UserID WHERE Post.TopicID = ? ORDER BY Post.PostID desc");
$statement3->bindValue(1, $topicID);
$statement3->execute();


?>

<!DOCTYPE html>
<html>
<head>
	<title>  </title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	
</head>
<body>
	<div class="container">
		<!--Header -->
		<div class="row", id="header">
			<h2>CSE4IFU - FORUM</h2>
		</div>
		<!-- Navigation bar -->
		<div class="row", id="nav">  
			<div class="link-container">
				<ul class="nav-list">
					<li><a href="Homepage.php">Home</a></li>
					<li><a href="Topics.php">Topics</a></li>
					<?php  if ($cookieUser == ""): ?>
						<li><a href="SignUp.php">Sign Up</a></li>
						<li><a href="SignIn.php">Sign In</a></li>
					<?php  else: ?>
						<li><a href="LogOutUser.php">Sign Out</a></li>
					<?php  endif; ?>
				</ul>
			</div>
			<?php  if ($cookieUser != ""):?>
				<div class="name-container">
					<p> <?php echo $cookieUser; ?> </p>
				</div>
			<?php  endif; ?>
		</div>

		<div class="row", id="content">
			<div class="topictitle"><h3><?php echo $thisTopic ?></h3></div>
			<div class="table">
				<table>
					<tr>
						<th class="user">User</th>
						<th class="post">Post</th>
						<th class="date">Date</th>
						<th class="likes">Likes</th>
					</tr>
					<?php 
					while ($row = $statement3->fetch(PDO::FETCH_ASSOC)) 
					{
						$userName = $row['UserName'];
						$fName = $row['FirstName'];
						$sName = $row['SurName'];
						$dateTime = $row['DateTime'];
						$text = $row['Post'];
						$tag = $row['Tag'];
						$likes = $row['Likes'];
						$postID = $row['PostID'];
						echo "<tr>";
						echo "<td>$userName<br><sup>$fName $sName</sup></td>";
						echo "<td><p id='post'>$text</p><p id='tagDisplay'>$tag</p></td>";
						echo "<td>$dateTime</td>";
						
						if ($cookieUser != "") {
							echo "<td>";
							echo "<form method = \"POST\" action = \"postLike.php?Topic=$thisTopic\" class= 'like-form'>";
							echo "<input type='hidden' name='postId' value='$postID'>";
							echo "<span>$likes</span>";
							echo "<button type='submit'>👍</button>";
							echo "</form>";
							echo "</td>";

						} else {
							echo "<td>$likes </td>";
						}
						echo "</tr>";
					}	

					?>
				</table>
				<div class="newtopicform-container">
					<div class="newtopic-form">
						<h3 id="topich3">Create new Post</h3><br>
						<?php if ($cookieUser == ""): ?>
							<p>You must be logged in to create a Post.</p>
						<?php else: ?>


							<?php 
							echo "<form method = \"POST\" action = \"AddPost.php?Topic=$thisTopic\">"

							?>
							<?php  if ($cookieMessage != ""): ?>
								<p><?php echo $cookieMessage; ?></p>
							<?php  endif; ?>
							<div>
								<label for="post">Post</label>
								<input type="text" id="post" name="Post" required><br>
							</div>
							<div> 
								<button class="submitbtn-topic" type="submit">Submit</button>
							</div> 

						</form>
					<?php endif;?>
				</div>

			</div>

		</div>

	</div>
	<div class="row", id="footer">
		<div> 
			<h3 class="footer-text"> Pramodani Kanchanamala Jayakodi Jayakodi Mudiyanselage - 21978017 - CSE4IFU-2023, Sem 1</h3>
		</div>
	</div>
</div>
</body>
</html>