<?php // <--- do NOT put anything before this PHP tag

// this php file will have no HTML
session_start();

include('Functions.php');

?>

<?php

if (isset($_POST["UserName"])){

  $dbh = connectToDatabase();

  $UserName = trim($_POST["UserName"]);
  $_SESSION['SignInForm'] = $_POST;

  if (empty($UserName)) {
    setCookieMessage("Username not provided");
    redirect("SignIn.php");

  }else {

    $statement = $dbh->prepare("SELECT UserName FROM User WHERE UserName = ? COLLATE NOCASE;");
    $statement->bindValue(1, $UserName);
    $statement->execute();

    if ($statement->fetch(PDO::FETCH_ASSOC)) {
     setCookieUser($UserName);
     setCookieMessage("Welcome back ". $UserName. " !");
     redirect("Homepage.php");

   }else {
     setCookieMessage("The username: " . $UserName . " does not exist");
     redirect("SignIn.php");

   }
 }

}

?>

